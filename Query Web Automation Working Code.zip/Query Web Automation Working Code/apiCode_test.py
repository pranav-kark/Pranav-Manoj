from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from msedge.selenium_tools import Edge, EdgeOptions
from selenium.webdriver.support import expected_conditions as EC
import time
from tkinter import Tk, simpledialog
from fastapi import BackgroundTasks, FastAPI
import uvicorn


app=FastAPI()

@app.get("/")

def root():
    return {"message":"ready to download"}

def wait_for_element_to_load(driver, by, value, timeout=600):
    try:
        element = WebDriverWait(driver, timeout).until(
            EC.presence_of_element_located((by, value))
        )
        return element
    except TimeoutException:
        print(f"Element {by}='{value}' not found within {timeout} seconds.")
        return None
    
# Custom function to wait for shadow element
def wait_for_shadow_element(driver, css_selector, shadow_root):
    return WebDriverWait(driver, 600).until(
        lambda x: driver.execute_script(f'return arguments[0].querySelector("{css_selector}")', shadow_root)
    )

def automation(user_input):
    EDGEDRIVER_PATH = r"E:\msedgedriver.exe"
    edge_options = EdgeOptions()
    driver = Edge(executable_path = EDGEDRIVER_PATH, options = edge_options)
    driver.get('https://app.meltwater.com/login')


    wait = WebDriverWait(driver, 50)  # Adjust the timeout as needed
    wait.until(lambda driver: driver.execute_script("return document.readyState === 'complete';"))

    form1 = driver.find_element(By.NAME, 'email')
    email = 'vruchita.raut@cal-saig.com'
    form1.send_keys(email)

    buttons = driver.find_elements(By.TAG_NAME, 'button')
    button1 = buttons[0]
    button1.text
    button1.click()
    time.sleep(5)
    password = driver.find_element(By.ID, 'password')
    password_text = 'P@ssw0rd@231'
    password.send_keys(password_text)
    buttons2 = driver.find_elements(By.TAG_NAME, 'button')
    button2 = buttons2[2]
    button2.click()
    driver.maximize_window()

    print('Logged in')

    # wait_element = wait_for_element_to_load(driver, By.XPATH, '//*[@id="mw"]/mi-app-chrome/ia-app-root/stencil-router/stencil-route-switch/stencil-route/ia-home/mi-app-chrome-content/div/div[2]/div[1]/div/ia-core-features/div/div[1]', timeout=120)
    wait_element = wait_for_element_to_load(driver, By.XPATH, '(//ia-content-card[@tabindex="0"])', timeout=120)

    # time.sleep(5)

    mapped = {
        'rdq' : 'Risk Dashboard Query',
        'tita' : 'Titagarh',
        'pref' : 'Preferred/Horizon Data Capture V2',
        'adani' : 'ADANI-RIL-TATA',
        'shell' : 'Shell-BP-Chevron'
    }

    # Check if the user input is a short word in the dictionary
    if user_input in mapped:
        long_word = mapped[user_input]
        print("You entered:", user_input)
        print("Query Chosen:", long_word)

    query_buttons = driver.find_elements(By.XPATH, '(//ia-content-card[@tabindex="0"])') 

    for i in range(len(query_buttons)):
        button_text = query_buttons[i].text
        if long_word in button_text:
            query_buttons[i].click()
            break  
    else:
        print("No button with text containing" + user_input +  "found.")

    wait_date = wait_for_element_to_load(driver, By.TAG_NAME, 'button')
    buttons3 = driver.find_elements(By.TAG_NAME, 'button')
    button3 = buttons3[1]
    button3.click()
    
    xpath_expression = '//button[contains(@class, "md-no-style") and contains(@ng-click, "handleClick") and @aria-label="Today"]'
    button4 = driver.find_element(By.XPATH, xpath_expression)

    button4.click()

    print('Reached here')

    # Define a WebDriverWait object
    wait = WebDriverWait(driver, 600)

    # Locate and wait for the first shadow root host
    shadow0_host = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "cw-content-stream[class='hydrated']")))
    shadow0 = driver.execute_script('return arguments[0].shadowRoot', shadow0_host)
    # Locate and wait for the second shadow root host
    shadow1_host = wait_for_shadow_element(driver, ".hydrated", shadow0)
    shadow1 = driver.execute_script('return arguments[0].shadowRoot', shadow1_host)
    # Locate and wait for the third shadow root host
    shadow2_host = wait_for_shadow_element(driver, "flux-content-stream-header[class='hydrated']", shadow1)
    shadow2 = driver.execute_script('return arguments[0].shadowRoot', shadow2_host)
    # Locate and wait for the fourth shadow root host
    shadow3_host_css = "div:nth-child(1) > div:nth-child(2) > flux-action-bar:nth-child(1) > flux-dropdown:nth-child(2) > flux-button:nth-child(1)"
    shadow3_host = wait_for_shadow_element(driver, shadow3_host_css, shadow2)
    shadow3 = driver.execute_script('return arguments[0].shadowRoot', shadow3_host)
    # Locate and wait for the target element within the fourth shadow root
    target_element_css = ".button.hasIcon.type-text.type-round.tint-secondary"
    downloadButton = wait_for_shadow_element(driver, target_element_css, shadow3)

    actions = ActionChains(driver)
    actions.click(downloadButton).perform()


    try:
        shadow0_host = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "cw-content-stream[class='hydrated']")))
        shadow0 = driver.execute_script('return arguments[0].shadowRoot', shadow0_host)
        shadow1_host = wait_for_shadow_element(driver, ".hydrated", shadow0)
        shadow1 = driver.execute_script('return arguments[0].shadowRoot', shadow1_host)
        shadow2_host = wait_for_shadow_element(driver, "flux-content-stream-header[class='hydrated']", shadow1)
        shadow2 = driver.execute_script('return arguments[0].shadowRoot', shadow2_host)
        shadow3_host = wait_for_shadow_element(driver, "flux-list-item[type='standard']", shadow2)
        shadow3 = driver.execute_script('return arguments[0].shadowRoot', shadow3_host)
        target_element_css = ".flux-list-item__default-slot"
        csvDownloadButton = wait_for_shadow_element(driver, target_element_css, shadow3)
        time.sleep(2)
        actions.click(csvDownloadButton).perform()
    except:
        shadow0_host = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "cw-content-stream[class='hydrated']")))
        shadow0 = driver.execute_script('return arguments[0].shadowRoot', shadow0_host)
        shadow1_host = wait_for_shadow_element(driver, ".hydrated", shadow0)
        shadow1 = driver.execute_script('return arguments[0].shadowRoot', shadow1_host)
        shadow2_host = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "flux-content-stream-header[class=\'hydrated\']")))
        shadow2 = driver.execute_script('return arguments[0].shadowRoot', shadow2_host)
        shadow3_host = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "div:nth-child(1) > div:nth-child(2) > flux-action-bar:nth-child(1) > flux-dropdown:nth-child(2) > flux-list:nth-child(2) > flux-list-item:nth-child(1)")))
        shadow3 = driver.execute_script('return arguments[0].shadowRoot', shadow3_host)
        target_element_css = ".flux-list-item__default-slot"
        csvDownloadButton = wait_for_shadow_element(driver, target_element_css, shadow3)
        time.sleep(2)
        actions.click(csvDownloadButton).perform()
    finally:
        driver.quit()
    return long_word

            
def combine(user_input):
    query_name=automation(user_input)
    print(f'{query_name} download completed')

def perform_http_call():
    # Perform your HTTP call here
    response = {'Message' : "Http returned"}
    return response

@app.get('/final/{user_input}')
async def final(user_input, background_tasks: BackgroundTasks):
    
    response=perform_http_call()
    
    background_tasks.add_task(combine, user_input)
    
    return response

if __name__ == "__main__":
    uvicorn.run(app)
    # automation()
    # driver.quit()