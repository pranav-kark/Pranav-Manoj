import requests

user_input='adani'
# sending data to fastapi
print('sending data to fastapi')
api_url = f'http://localhost:8000/final/{user_input}'
response = requests.get(api_url)
headers = response.headers
print('')
print(f'Status code: {response.status_code}')
for key, value in headers.items():
    if key not in ['Content-Type', 'Content-Length', 'Connection', 'Date', 'Server', 'Content-Disposition', 'Cache-Control']:
        print(f'{key}:{value}')
if response.status_code == 200:
    print('\nDownload successful  ;p')
else:
    print('\nFailed to Download')


user_input='shell'
# sending data to fastapi
print('sending data to fastapi')
api_url = f'http://localhost:8000/final/{user_input}'
response = requests.get(api_url)
headers = response.headers
print('')
print(f'Status code: {response.status_code}')
for key, value in headers.items():
    if key not in ['Content-Type', 'Content-Length', 'Connection', 'Date', 'Server', 'Content-Disposition', 'Cache-Control']:
        print(f'{key}:{value}')
if response.status_code == 200:
    print('\nDownload successful  ;p')
else:
    print('\nFailed to Download')

user_input='pref'
# sending data to fastapi
print('sending data to fastapi')
api_url = f'http://localhost:8000/final/{user_input}'
response = requests.get(api_url)
headers = response.headers
print('')
print(f'Status code: {response.status_code}')
for key, value in headers.items():
    if key not in ['Content-Type', 'Content-Length', 'Connection', 'Date', 'Server', 'Content-Disposition', 'Cache-Control']:
        print(f'{key}:{value}')
if response.status_code == 200:
    print('\nDownload successful  ;p')
else:
    print('\nFailed to Download')

user_input='rdq'
# sending data to fastapi
print('sending data to fastapi')
api_url = f'http://localhost:8000/final/{user_input}'
response = requests.get(api_url)
headers = response.headers
print('')
print(f'Status code: {response.status_code}')
for key, value in headers.items():
    if key not in ['Content-Type', 'Content-Length', 'Connection', 'Date', 'Server', 'Content-Disposition', 'Cache-Control']:
        print(f'{key}:{value}')
if response.status_code == 200:
    print('\nDownload successful  ;p')
else:
    print('\nFailed to Download')