from telethon.sync import TelegramClient

# Your API credentials
api_id = '25030263'
api_hash = 'ef0cfd59c74a5d15d5da360be545ca95'

# Your phone number
phone = '+919360465743'

# Chat URL (replace with your chat's URL)
chat_url = 'https://t.me/anglebrokinganglebroking'  # Replace with your actual chat URL

# Extract the chat ID from the URL
chat_id = chat_url.split('/')[-1]

# Create a TelegramClient
client = TelegramClient('session_name', api_id, api_hash)

async def main(phone):
    await client.start(phone)
    
    # Check if you are an admin in the chat
    chat = await client.get_entity(chat_id)
    if not chat.creator:
        print("You are not an admin in this chat.")
        return
    
    # Now you can perform the action that requires admin privileges
    
    await client.run_until_disconnected()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main(phone))
