import pandas as pd
import json

# Load JSON data into a Python object
with open('ExtractedFiles\\anglebrokinganglebroking.json', 'r') as f:
    json_data = json.load(f)

# Convert the JSON object to a DataFrame
df = pd.DataFrame(json_data)

# Display the DataFrame
print(df.head())

df.to_csv('ExtractedFiles/anglebrokinganglebroking.csv')